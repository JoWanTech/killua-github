﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Threading.Tasks



Namespace Typ
    Public Enum Nachrichtenstatustyp
        Received = 0
        Send = 1
        Seen = 2
    End Enum

    Public Enum Nachrichtentyp
        Text = 0
        Video = 1
        Audio = 2
        Image = 3
    End Enum

    Public Enum Userstatustyp
        Online = 0
        Offline = 1
        Busy = 2
    End Enum


End Namespace