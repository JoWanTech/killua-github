﻿
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Public Class frmLogin
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Friend WithEvents ChatAppDataSetBindingSource As BindingSource
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents pnlLogin As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents picLogClose As PictureBox
    Friend WithEvents liklabPwassword As LinkLabel
    Friend WithEvents btnLogin As Button
    Friend WithEvents txbEmail As TextBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents txbPassword As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents ckBesaetigung As CheckBox
    Friend WithEvents txbNachname As TextBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Panel1 As Panel

#Region "Windows Form-Designer"

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLogin))
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnFrmSignup = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnFrmLogin = New System.Windows.Forms.Button()
        Me.pnlRegister = New System.Windows.Forms.Panel()
        Me.txbNachname = New System.Windows.Forms.TextBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ckBesaetigung = New System.Windows.Forms.CheckBox()
        Me.txbVorname = New System.Windows.Forms.TextBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.txbRePassword = New System.Windows.Forms.TextBox()
        Me.txbReEmail = New System.Windows.Forms.TextBox()
        Me.picSignClose = New System.Windows.Forms.PictureBox()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.cmbAnrede = New System.Windows.Forms.ComboBox()
        Me.btnSIGNUP = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.labBedingung = New System.Windows.Forms.RichTextBox()
        Me.ChatAppDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.pnlLogin = New System.Windows.Forms.Panel()
        Me.txbEmail = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.picLogClose = New System.Windows.Forms.PictureBox()
        Me.liklabPwassword = New System.Windows.Forms.LinkLabel()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.txbPassword = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.pnlRegister.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSignClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChatAppDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlLogin.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLogClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(429, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(185, 22)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Ein Account anlegen?"
        '
        'btnFrmSignup
        '
        Me.btnFrmSignup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFrmSignup.Location = New System.Drawing.Point(437, 193)
        Me.btnFrmSignup.Name = "btnFrmSignup"
        Me.btnFrmSignup.Size = New System.Drawing.Size(77, 26)
        Me.btnFrmSignup.TabIndex = 8
        Me.btnFrmSignup.Text = "SIGN UP"
        Me.btnFrmSignup.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(433, 173)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 22)
        Me.Label3.TabIndex = 9
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.ForeColor = System.Drawing.Color.White
        Me.RichTextBox1.Location = New System.Drawing.Point(433, 122)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(250, 65)
        Me.RichTextBox1.TabIndex = 10
        Me.RichTextBox1.Text = "Mit der Erstellung eines Kontos erklären Sie sich mit unseren Allgemeinen Geschäf" &
    "tsbedingungen und dem Datenschutz einverstanden."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(49, 173)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 22)
        Me.Label5.TabIndex = 13
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(49, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(181, 22)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Hast du ein Account?"
        '
        'btnFrmLogin
        '
        Me.btnFrmLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFrmLogin.Location = New System.Drawing.Point(49, 193)
        Me.btnFrmLogin.Name = "btnFrmLogin"
        Me.btnFrmLogin.Size = New System.Drawing.Size(77, 26)
        Me.btnFrmLogin.TabIndex = 12
        Me.btnFrmLogin.Text = "LOG IN"
        Me.btnFrmLogin.UseVisualStyleBackColor = False
        '
        'pnlRegister
        '
        Me.pnlRegister.BackColor = System.Drawing.SystemColors.Control
        Me.pnlRegister.Controls.Add(Me.txbNachname)
        Me.pnlRegister.Controls.Add(Me.PictureBox6)
        Me.pnlRegister.Controls.Add(Me.Panel1)
        Me.pnlRegister.Controls.Add(Me.ckBesaetigung)
        Me.pnlRegister.Controls.Add(Me.txbVorname)
        Me.pnlRegister.Controls.Add(Me.PictureBox5)
        Me.pnlRegister.Controls.Add(Me.PictureBox3)
        Me.pnlRegister.Controls.Add(Me.PictureBox4)
        Me.pnlRegister.Controls.Add(Me.txbRePassword)
        Me.pnlRegister.Controls.Add(Me.txbReEmail)
        Me.pnlRegister.Controls.Add(Me.picSignClose)
        Me.pnlRegister.Controls.Add(Me.Panel10)
        Me.pnlRegister.Controls.Add(Me.cmbAnrede)
        Me.pnlRegister.Controls.Add(Me.btnSIGNUP)
        Me.pnlRegister.Controls.Add(Me.Panel6)
        Me.pnlRegister.Controls.Add(Me.Panel7)
        Me.pnlRegister.Controls.Add(Me.Panel8)
        Me.pnlRegister.Controls.Add(Me.Label4)
        Me.pnlRegister.Controls.Add(Me.labBedingung)
        Me.pnlRegister.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlRegister.Location = New System.Drawing.Point(377, 0)
        Me.pnlRegister.Name = "pnlRegister"
        Me.pnlRegister.Size = New System.Drawing.Size(378, 380)
        Me.pnlRegister.TabIndex = 14
        '
        'txbNachname
        '
        Me.txbNachname.BackColor = System.Drawing.SystemColors.Control
        Me.txbNachname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbNachname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbNachname.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbNachname.Location = New System.Drawing.Point(133, 134)
        Me.txbNachname.Name = "txbNachname"
        Me.txbNachname.Size = New System.Drawing.Size(173, 17)
        Me.txbNachname.TabIndex = 23
        Me.txbNachname.Text = "Nachname"
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImage = Global.ChatApp.My.Resources.Resources.profil
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox6.Location = New System.Drawing.Point(102, 122)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox6.TabIndex = 25
        Me.PictureBox6.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(133, 153)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(173, 1)
        Me.Panel1.TabIndex = 24
        '
        'ckBesaetigung
        '
        Me.ckBesaetigung.AutoSize = True
        Me.ckBesaetigung.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ckBesaetigung.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ckBesaetigung.Location = New System.Drawing.Point(29, 257)
        Me.ckBesaetigung.Name = "ckBesaetigung"
        Me.ckBesaetigung.Size = New System.Drawing.Size(12, 11)
        Me.ckBesaetigung.TabIndex = 22
        Me.ckBesaetigung.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.ckBesaetigung.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ckBesaetigung.UseVisualStyleBackColor = True
        '
        'txbVorname
        '
        Me.txbVorname.BackColor = System.Drawing.SystemColors.Control
        Me.txbVorname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbVorname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbVorname.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbVorname.Location = New System.Drawing.Point(133, 99)
        Me.txbVorname.Name = "txbVorname"
        Me.txbVorname.Size = New System.Drawing.Size(173, 17)
        Me.txbVorname.TabIndex = 9
        Me.txbVorname.Text = "Vorname"
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = Global.ChatApp.My.Resources.Resources.profil
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox5.Location = New System.Drawing.Point(102, 87)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox5.TabIndex = 21
        Me.PictureBox5.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox3.Location = New System.Drawing.Point(29, 179)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox3.TabIndex = 19
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Location = New System.Drawing.Point(29, 218)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox4.TabIndex = 20
        Me.PictureBox4.TabStop = False
        '
        'txbRePassword
        '
        Me.txbRePassword.BackColor = System.Drawing.SystemColors.Control
        Me.txbRePassword.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbRePassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbRePassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbRePassword.Location = New System.Drawing.Point(61, 224)
        Me.txbRePassword.Name = "txbRePassword"
        Me.txbRePassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txbRePassword.Size = New System.Drawing.Size(173, 17)
        Me.txbRePassword.TabIndex = 2
        Me.txbRePassword.Text = "Password"
        '
        'txbReEmail
        '
        Me.txbReEmail.BackColor = System.Drawing.SystemColors.Control
        Me.txbReEmail.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbReEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbReEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbReEmail.Location = New System.Drawing.Point(61, 190)
        Me.txbReEmail.Name = "txbReEmail"
        Me.txbReEmail.Size = New System.Drawing.Size(173, 17)
        Me.txbReEmail.TabIndex = 1
        Me.txbReEmail.Text = "Email"
        '
        'picSignClose
        '
        Me.picSignClose.BackgroundImage = Global.ChatApp.My.Resources.Resources.close
        Me.picSignClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.picSignClose.Location = New System.Drawing.Point(360, 3)
        Me.picSignClose.Name = "picSignClose"
        Me.picSignClose.Size = New System.Drawing.Size(17, 18)
        Me.picSignClose.TabIndex = 15
        Me.picSignClose.TabStop = False
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.Black
        Me.Panel10.Location = New System.Drawing.Point(133, 118)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(173, 1)
        Me.Panel10.TabIndex = 12
        '
        'cmbAnrede
        '
        Me.cmbAnrede.BackColor = System.Drawing.SystemColors.Control
        Me.cmbAnrede.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmbAnrede.FormattingEnabled = True
        Me.cmbAnrede.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.cmbAnrede.Items.AddRange(New Object() {"Herr", "Frau"})
        Me.cmbAnrede.Location = New System.Drawing.Point(29, 95)
        Me.cmbAnrede.Name = "cmbAnrede"
        Me.cmbAnrede.Size = New System.Drawing.Size(67, 21)
        Me.cmbAnrede.TabIndex = 7
        Me.cmbAnrede.Text = "Anrede"
        '
        'btnSIGNUP
        '
        Me.btnSIGNUP.BackColor = System.Drawing.Color.Chocolate
        Me.btnSIGNUP.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSIGNUP.Location = New System.Drawing.Point(258, 309)
        Me.btnSIGNUP.Name = "btnSIGNUP"
        Me.btnSIGNUP.Size = New System.Drawing.Size(77, 26)
        Me.btnSIGNUP.TabIndex = 5
        Me.btnSIGNUP.Text = "SIGN UP"
        Me.btnSIGNUP.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Black
        Me.Panel6.Location = New System.Drawing.Point(61, 242)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(173, 1)
        Me.Panel6.TabIndex = 4
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Black
        Me.Panel7.Location = New System.Drawing.Point(61, 210)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(173, 1)
        Me.Panel7.TabIndex = 3
        '
        'Panel8
        '
        Me.Panel8.Location = New System.Drawing.Point(61, 203)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(156, 1)
        Me.Panel8.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(60, 58)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 22)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "SIGN UP"
        '
        'labBedingung
        '
        Me.labBedingung.BackColor = System.Drawing.SystemColors.Control
        Me.labBedingung.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.labBedingung.ForeColor = System.Drawing.Color.Black
        Me.labBedingung.Location = New System.Drawing.Point(49, 257)
        Me.labBedingung.Name = "labBedingung"
        Me.labBedingung.Size = New System.Drawing.Size(250, 46)
        Me.labBedingung.TabIndex = 13
        Me.labBedingung.Text = "Mit der Erstellung eines Kontos erklären Sie sich mit unseren Allgemeinen Geschäf" &
    "tsbedingungen und dem Datenschutz einverstanden."
        '
        'pnlLogin
        '
        Me.pnlLogin.BackColor = System.Drawing.SystemColors.Control
        Me.pnlLogin.Controls.Add(Me.txbEmail)
        Me.pnlLogin.Controls.Add(Me.PictureBox1)
        Me.pnlLogin.Controls.Add(Me.picLogClose)
        Me.pnlLogin.Controls.Add(Me.liklabPwassword)
        Me.pnlLogin.Controls.Add(Me.btnLogin)
        Me.pnlLogin.Controls.Add(Me.Panel4)
        Me.pnlLogin.Controls.Add(Me.Panel3)
        Me.pnlLogin.Controls.Add(Me.txbPassword)
        Me.pnlLogin.Controls.Add(Me.Label1)
        Me.pnlLogin.Controls.Add(Me.PictureBox2)
        Me.pnlLogin.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlLogin.Location = New System.Drawing.Point(0, 0)
        Me.pnlLogin.Name = "pnlLogin"
        Me.pnlLogin.Size = New System.Drawing.Size(377, 380)
        Me.pnlLogin.TabIndex = 15
        '
        'txbEmail
        '
        Me.txbEmail.BackColor = System.Drawing.SystemColors.Control
        Me.txbEmail.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbEmail.Location = New System.Drawing.Point(55, 153)
        Me.txbEmail.Name = "txbEmail"
        Me.txbEmail.Size = New System.Drawing.Size(173, 17)
        Me.txbEmail.TabIndex = 1
        Me.txbEmail.Text = "Email"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox1.Location = New System.Drawing.Point(22, 141)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox1.TabIndex = 17
        Me.PictureBox1.TabStop = False
        '
        'picLogClose
        '
        Me.picLogClose.BackgroundImage = Global.ChatApp.My.Resources.Resources.close
        Me.picLogClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.picLogClose.Location = New System.Drawing.Point(3, 3)
        Me.picLogClose.Name = "picLogClose"
        Me.picLogClose.Size = New System.Drawing.Size(17, 18)
        Me.picLogClose.TabIndex = 16
        Me.picLogClose.TabStop = False
        '
        'liklabPwassword
        '
        Me.liklabPwassword.AutoSize = True
        Me.liklabPwassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.liklabPwassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.liklabPwassword.LinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.liklabPwassword.Location = New System.Drawing.Point(52, 312)
        Me.liklabPwassword.Name = "liklabPwassword"
        Me.liklabPwassword.Size = New System.Drawing.Size(155, 18)
        Me.liklabPwassword.TabIndex = 6
        Me.liklabPwassword.TabStop = True
        Me.liklabPwassword.Text = "Password vergessen?"
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.Color.Chocolate
        Me.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogin.Location = New System.Drawing.Point(259, 309)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(77, 26)
        Me.btnLogin.TabIndex = 5
        Me.btnLogin.Text = "LOG IN"
        Me.btnLogin.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Black
        Me.Panel4.Location = New System.Drawing.Point(55, 210)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(173, 1)
        Me.Panel4.TabIndex = 4
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Black
        Me.Panel3.Location = New System.Drawing.Point(55, 172)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(173, 1)
        Me.Panel3.TabIndex = 3
        '
        'txbPassword
        '
        Me.txbPassword.BackColor = System.Drawing.SystemColors.Control
        Me.txbPassword.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbPassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txbPassword.Location = New System.Drawing.Point(55, 190)
        Me.txbPassword.Name = "txbPassword"
        Me.txbPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txbPassword.Size = New System.Drawing.Size(173, 17)
        Me.txbPassword.TabIndex = 2
        Me.txbPassword.Text = "Password"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(55, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 22)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "LOG IN"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(22, 179)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox2.TabIndex = 18
        Me.PictureBox2.TabStop = False
        '
        'frmLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(755, 380)
        Me.Controls.Add(Me.pnlLogin)
        Me.Controls.Add(Me.pnlRegister)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnFrmLogin)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnFrmSignup)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.RichTextBox1)
        Me.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmLogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "guiLogin"
        Me.pnlRegister.ResumeLayout(False)
        Me.pnlRegister.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSignClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChatAppDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlLogin.ResumeLayout(False)
        Me.pnlLogin.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLogClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents btnFrmSignup As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnFrmLogin As Button
    Friend WithEvents pnlRegister As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents txbVorname As TextBox
    Friend WithEvents cmbAnrede As ComboBox
    Friend WithEvents btnSIGNUP As Button
    Friend WithEvents txbReEmail As TextBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents txbRePassword As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents labBedingung As RichTextBox
    Friend WithEvents picSignClose As PictureBox
#End Region

    Sub New()
        InitializeComponent()
        pnlRegister.Visible = False

    End Sub

#Region "Declarations"

    Dim nStartPos As Point
    Dim nDragPos As Point


    Private Sub DataLogin()
        Dim Password As String
        Dim Email As String

        Dim mycon As New Databaseconn.Dataconn
        Dim command As New SqlCommand("SELECT  Email, Password FROM  benutzer WHERE   (Email = '" & txbEmail.Text & "' ) AND (Password = '" & txbPassword.Text & "')", mycon.conn)
        mycon.conn.Open()
        Dim dataReader As SqlDataReader = command.ExecuteReader()

        If dataReader.HasRows Then
            While dataReader.Read()
                Password = dataReader("Password").ToString()
                Email = dataReader("Email").ToString()
                If txbPassword.Text = dataReader("Password") And txbEmail.Text = dataReader("Email") Then
                    MessageBox.Show("Erfolgreich angemeldet als " & dataReader("Email"), "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    frmDeskTop.Show()
                    Me.Hide()
                    txbPassword.Text = ""
                    txbEmail.Text = ""
                End If
            End While
        Else
            MsgBox("Passwort oder Email stimmt nicht", MsgBoxStyle.Critical, "Falsche Eingaben!")
        End If
        mycon.conn.Close()

    End Sub


    'Private Function AnredeData()
    '    If cmbAnrede.Text = "Herr" Then
    '        cmbAnrede.Text = 1
    '    ElseIf cmbAnrede.Text = "Frau" Then
    '        cmbAnrede.Text = 2
    '    Else
    '        MsgBox("Bitte die Anrede auswählen", MsgBoxStyle.Critical, "Anrede")
    '        Exit Function
    '    End If
    '    Return AnredeData()
    'End Function



    Private Sub DataSign()
        Dim mycon As New Databaseconn.Dataconn
        Dim command As New SqlCommand("insert into benutzer (Anrede_Id, vorname, Nachname, email, erstellt_am, upgedatet_am, Password, Bestaetigung)
                                                     values (@Anrede_Id, @vorname, @Nachname,@email, @erstellt_am, @upgedatet_am, @password, @Bestaetigung)", mycon.conn)
        command.Parameters.Add("@Anrede_Id", SqlDbType.VarChar).Value = ""
        command.Parameters.Add("@email", SqlDbType.VarChar).Value = txbReEmail.Text
        command.Parameters.Add("@password", SqlDbType.VarChar).Value = txbRePassword.Text
        command.Parameters.Add("@upgedatet_am", SqlDbType.DateTime).Value = DateTime.Now
        command.Parameters.Add("@erstellt_am", SqlDbType.DateTime).Value = DateTime.Now
        command.Parameters.Add("@bevorzugungen", SqlDbType.VarChar).Value = ""
        command.Parameters.Add("@vorname", SqlDbType.VarChar).Value = txbVorname.Text
        command.Parameters.Add("@Nachname", SqlDbType.VarChar).Value = txbNachname.Text
        command.Parameters.Add("@Bestaetigung", SqlDbType.VarChar).Value = ckBesaetigung.Checked
        Dim adapter As New SqlDataAdapter(command)

        Dim table As New DataTable()
        adapter.Fill(table)
        If table.Rows.Count() <= 0 Then
            MessageBox.Show("Sie Wurden erfolgreich registriert")
        Else
            MessageBox.Show("Die Verbindung zur Datenbank ist schiefgelaufen!")
        End If
        mycon.conn.Close()
    End Sub


#End Region

#Region "communication event handler"

#End Region

#Region "properties"

#End Region

#Region "internals"
    Public Function validierenEmail(EmailAdresse) As Boolean
        Dim email As New Regex("([\w-+]+(?:\.[\w-+]+)*@)(?:[\w-+]+\.)+[a-zA-Z]{2,7}")
        If email.IsMatch(EmailAdresse) Then
            Return True
        Else
            Return False
        End If
    End Function


#End Region

#Region "Ereignisse"


    Private Sub btnFrmSignup_Click(sender As Object, e As EventArgs) Handles btnFrmSignup.Click
        pnlLogin.Visible = False
        pnlRegister.Show()
    End Sub

    Private Sub btnFrmLogin_Click(sender As Object, e As EventArgs) Handles btnFrmLogin.Click
        pnlRegister.Visible = False
        pnlLogin.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles picLogClose.Click
        Me.Close()
    End Sub

    Private Sub picschliessen_Click(sender As Object, e As EventArgs) Handles picSignClose.Click
        Me.Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        If validierenEmail(txbEmail.Text) = False Then
            MsgBox("Bitte überprüfen Sie Ihre EmailAdresse", MsgBoxStyle.Critical, "Email?")
            txbEmail.ForeColor = Color.Red
        Else
            DataLogin()
        End If
    End Sub
    Private Sub btnSIGNUP_Click(sender As Object, e As EventArgs) Handles btnSIGNUP.Click
        If ckBesaetigung.Checked = False Then
            MsgBox("Bitte Bestätigen Sie die unsere Bedingung!", MsgBoxStyle.Critical, "Bestätigung!")
            labBedingung.ForeColor = Color.Red
        Else
            If validierenEmail(txbReEmail.Text) = False Then
                MsgBox("Überprüfen Sie Ihre Email!", MsgBoxStyle.Critical, "Email Überprüfen!")
                txbReEmail.ForeColor = Color.Red
            Else
                DataSign()
            End If
        End If
    End Sub
    Private Sub RichTextBox2_Click(sender As Object, e As EventArgs) Handles labBedingung.Click
        ckBesaetigung.Checked = True
        If ckBesaetigung.Checked Then
            btnSIGNUP.BackColor = Color.Green
        Else
            btnSIGNUP.BackColor = Color.Chocolate
        End If
    End Sub

    Private Sub LiklabPwassword_Click(sender As Object, e As EventArgs) Handles liklabPwassword.Click
        frmDeskTop.Show()
    End Sub
    Private Sub GuiLogin_MouseDown(sender As Object, e As MouseEventArgs) Handles pnlRegister.MouseDown, pnlLogin.MouseDown, MyBase.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            nStartPos = Me.Location
            nDragPos = Me.PointToScreen(New Point(e.X, e.Y))
        End If
    End Sub
    Private Sub PnlLogin_MouseMove(sender As Object, e As MouseEventArgs) Handles pnlRegister.MouseMove, pnlLogin.MouseMove, MyBase.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Dim nCurPos As Point = Me.PointToScreen(New Point(e.X, e.Y))
            Me.Location = New Point(nStartPos.X + nCurPos.X - nDragPos.X,
              nStartPos.Y + nCurPos.Y - nDragPos.Y)
        End If
    End Sub


    Private Sub TxbEmail_Click(sender As Object, e As EventArgs) Handles txbEmail.Click
        txbEmail.Text = ""
    End Sub

    Private Sub TxbPassword_Click(sender As Object, e As EventArgs) Handles txbPassword.Click
        txbPassword.Text = ""
    End Sub

    Private Sub CheckBox1_Click(sender As Object, e As EventArgs) Handles ckBesaetigung.Click
        If ckBesaetigung.Checked = True Then
            btnSIGNUP.BackColor = Color.Green
        Else
            btnSIGNUP.BackColor = Color.Chocolate
        End If
    End Sub

#End Region
End Class