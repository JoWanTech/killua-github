﻿Imports System.IO
Imports System.IO.Ports
Imports System.Threading
Imports System
Imports System.Net.Mail

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
    Public Class frmDeskTop
        Inherits System.Windows.Forms.Form

        'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
        <System.Diagnostics.DebuggerNonUserCode()>
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub
        Friend WithEvents picschliessen As PictureBox
        Friend WithEvents labKopfName As Label
        Friend WithEvents Label1 As Label
    Friend WithEvents pnlkopf As Panel
    Friend WithEvents txtNachrichtBody As RichTextBox
    Friend WithEvents TimerSystemTimeClock As Windows.Forms.Timer
    Friend WithEvents onbtn As PictureBox
    Friend WithEvents btnConnectRemotePC As Button
    Friend WithEvents btnStartServer As Button
    Friend WithEvents tbRemoteIP As TextBox
    Public WithEvents tbServerIP As TextBox
    Friend WithEvents tbUsername As TextBox
#Region "Windows Form-Designer"
    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDeskTop))
        Me.pnlKontake = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnlunterKontakte = New System.Windows.Forms.Panel()
        Me.pnlSearch = New System.Windows.Forms.Panel()
        Me.txbSearch = New System.Windows.Forms.TextBox()
        Me.picSearch = New System.Windows.Forms.PictureBox()
        Me.btnConnectRemotePC = New System.Windows.Forms.Button()
        Me.btnStartServer = New System.Windows.Forms.Button()
        Me.tbRemoteIP = New System.Windows.Forms.TextBox()
        Me.tbServerIP = New System.Windows.Forms.TextBox()
        Me.tbUsername = New System.Windows.Forms.TextBox()
        Me.pnlfuss = New System.Windows.Forms.Panel()
        Me.btnSend = New System.Windows.Forms.PictureBox()
        Me.tbMessageToSend = New System.Windows.Forms.RichTextBox()
        Me.picschliessen = New System.Windows.Forms.PictureBox()
        Me.labKopfName = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlkopf = New System.Windows.Forms.Panel()
        Me.onbtn = New System.Windows.Forms.PictureBox()
        Me.txtNachrichtBody = New System.Windows.Forms.RichTextBox()
        Me.TimerSystemTimeClock = New System.Windows.Forms.Timer(Me.components)
        Me.pnlKontake.SuspendLayout()
        CType(Me.picSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlfuss.SuspendLayout()
        CType(Me.btnSend, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picschliessen, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlkopf.SuspendLayout()
        CType(Me.onbtn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlKontake
        '
        Me.pnlKontake.BackColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.pnlKontake.Controls.Add(Me.Label3)
        Me.pnlKontake.Controls.Add(Me.Label2)
        Me.pnlKontake.Controls.Add(Me.pnlunterKontakte)
        Me.pnlKontake.Controls.Add(Me.pnlSearch)
        Me.pnlKontake.Controls.Add(Me.txbSearch)
        Me.pnlKontake.Controls.Add(Me.picSearch)
        Me.pnlKontake.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlKontake.Location = New System.Drawing.Point(0, 0)
        Me.pnlKontake.Name = "pnlKontake"
        Me.pnlKontake.Size = New System.Drawing.Size(362, 708)
        Me.pnlKontake.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 16.0!)
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(312, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 25)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "+"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(12, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 21)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Kontakte"
        '
        'pnlunterKontakte
        '
        Me.pnlunterKontakte.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlunterKontakte.Location = New System.Drawing.Point(0, 336)
        Me.pnlunterKontakte.Name = "pnlunterKontakte"
        Me.pnlunterKontakte.Size = New System.Drawing.Size(362, 372)
        Me.pnlunterKontakte.TabIndex = 6
        '
        'pnlSearch
        '
        Me.pnlSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pnlSearch.Location = New System.Drawing.Point(35, 69)
        Me.pnlSearch.Name = "pnlSearch"
        Me.pnlSearch.Size = New System.Drawing.Size(281, 1)
        Me.pnlSearch.TabIndex = 1
        '
        'txbSearch
        '
        Me.txbSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.txbSearch.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txbSearch.Location = New System.Drawing.Point(35, 54)
        Me.txbSearch.Margin = New System.Windows.Forms.Padding(4)
        Me.txbSearch.Name = "txbSearch"
        Me.txbSearch.ShortcutsEnabled = False
        Me.txbSearch.Size = New System.Drawing.Size(276, 13)
        Me.txbSearch.TabIndex = 0
        Me.txbSearch.Text = "Search.."
        '
        'picSearch
        '
        Me.picSearch.BackgroundImage = Global.ChatApp.My.Resources.Resources.searchSymb
        Me.picSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.picSearch.Location = New System.Drawing.Point(313, 53)
        Me.picSearch.Name = "picSearch"
        Me.picSearch.Size = New System.Drawing.Size(21, 17)
        Me.picSearch.TabIndex = 5
        Me.picSearch.TabStop = False
        '
        'btnConnectRemotePC
        '
        Me.btnConnectRemotePC.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnConnectRemotePC.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConnectRemotePC.Font = New System.Drawing.Font("Arial Rounded MT Bold", 7.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnectRemotePC.ForeColor = System.Drawing.Color.Black
        Me.btnConnectRemotePC.Location = New System.Drawing.Point(520, 56)
        Me.btnConnectRemotePC.Margin = New System.Windows.Forms.Padding(2)
        Me.btnConnectRemotePC.Name = "btnConnectRemotePC"
        Me.btnConnectRemotePC.Size = New System.Drawing.Size(115, 20)
        Me.btnConnectRemotePC.TabIndex = 56
        Me.btnConnectRemotePC.Text = "Connect to Remote Server"
        Me.btnConnectRemotePC.UseVisualStyleBackColor = True
        '
        'btnStartServer
        '
        Me.btnStartServer.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnStartServer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStartServer.Font = New System.Drawing.Font("Arial Rounded MT Bold", 7.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStartServer.ForeColor = System.Drawing.Color.Black
        Me.btnStartServer.Location = New System.Drawing.Point(520, 29)
        Me.btnStartServer.Margin = New System.Windows.Forms.Padding(2)
        Me.btnStartServer.Name = "btnStartServer"
        Me.btnStartServer.Size = New System.Drawing.Size(115, 23)
        Me.btnStartServer.TabIndex = 55
        Me.btnStartServer.Text = "Start Local Server"
        Me.btnStartServer.UseVisualStyleBackColor = True
        '
        'tbRemoteIP
        '
        Me.tbRemoteIP.BackColor = System.Drawing.SystemColors.Control
        Me.tbRemoteIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbRemoteIP.Font = New System.Drawing.Font("Arial Rounded MT Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbRemoteIP.ForeColor = System.Drawing.Color.Black
        Me.tbRemoteIP.Location = New System.Drawing.Point(362, 53)
        Me.tbRemoteIP.Margin = New System.Windows.Forms.Padding(2)
        Me.tbRemoteIP.Name = "tbRemoteIP"
        Me.tbRemoteIP.Size = New System.Drawing.Size(154, 23)
        Me.tbRemoteIP.TabIndex = 54
        Me.tbRemoteIP.Text = "Remote IP Address"
        Me.tbRemoteIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbServerIP
        '
        Me.tbServerIP.BackColor = System.Drawing.SystemColors.Control
        Me.tbServerIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbServerIP.Font = New System.Drawing.Font("Arial Rounded MT Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbServerIP.ForeColor = System.Drawing.Color.Black
        Me.tbServerIP.Location = New System.Drawing.Point(362, 29)
        Me.tbServerIP.Margin = New System.Windows.Forms.Padding(2)
        Me.tbServerIP.Name = "tbServerIP"
        Me.tbServerIP.Size = New System.Drawing.Size(154, 23)
        Me.tbServerIP.TabIndex = 53
        Me.tbServerIP.Text = "Your IP Address"
        Me.tbServerIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbUsername
        '
        Me.tbUsername.BackColor = System.Drawing.SystemColors.Control
        Me.tbUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbUsername.Font = New System.Drawing.Font("Arial Rounded MT Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbUsername.ForeColor = System.Drawing.Color.Black
        Me.tbUsername.Location = New System.Drawing.Point(362, 2)
        Me.tbUsername.Margin = New System.Windows.Forms.Padding(2)
        Me.tbUsername.Name = "tbUsername"
        Me.tbUsername.Size = New System.Drawing.Size(154, 23)
        Me.tbUsername.TabIndex = 52
        Me.tbUsername.Text = "User Name"
        Me.tbUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlfuss
        '
        Me.pnlfuss.Controls.Add(Me.btnSend)
        Me.pnlfuss.Controls.Add(Me.tbMessageToSend)
        Me.pnlfuss.Location = New System.Drawing.Point(362, 660)
        Me.pnlfuss.Name = "pnlfuss"
        Me.pnlfuss.Size = New System.Drawing.Size(559, 48)
        Me.pnlfuss.TabIndex = 2
        '
        'btnSend
        '
        Me.btnSend.BackgroundImage = Global.ChatApp.My.Resources.Resources.send1
        Me.btnSend.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnSend.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnSend.Location = New System.Drawing.Point(529, 0)
        Me.btnSend.Name = "btnSend"
        Me.btnSend.Size = New System.Drawing.Size(30, 48)
        Me.btnSend.TabIndex = 2
        Me.btnSend.TabStop = False
        '
        'tbMessageToSend
        '
        Me.tbMessageToSend.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tbMessageToSend.Dock = System.Windows.Forms.DockStyle.Left
        Me.tbMessageToSend.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbMessageToSend.Location = New System.Drawing.Point(0, 0)
        Me.tbMessageToSend.Name = "tbMessageToSend"
        Me.tbMessageToSend.Size = New System.Drawing.Size(529, 48)
        Me.tbMessageToSend.TabIndex = 0
        Me.tbMessageToSend.Text = ""
        '
        'picschliessen
        '
        Me.picschliessen.BackgroundImage = Global.ChatApp.My.Resources.Resources.close
        Me.picschliessen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.picschliessen.Dock = System.Windows.Forms.DockStyle.Right
        Me.picschliessen.Location = New System.Drawing.Point(176, 0)
        Me.picschliessen.Name = "picschliessen"
        Me.picschliessen.Size = New System.Drawing.Size(19, 62)
        Me.picschliessen.TabIndex = 1
        Me.picschliessen.TabStop = False
        '
        'labKopfName
        '
        Me.labKopfName.AutoSize = True
        Me.labKopfName.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labKopfName.Location = New System.Drawing.Point(87, 9)
        Me.labKopfName.Name = "labKopfName"
        Me.labKopfName.Size = New System.Drawing.Size(57, 21)
        Me.labKopfName.TabIndex = 2
        Me.labKopfName.Text = "Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(107, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "23.12.2019"
        '
        'pnlkopf
        '
        Me.pnlkopf.Controls.Add(Me.onbtn)
        Me.pnlkopf.Controls.Add(Me.Label1)
        Me.pnlkopf.Controls.Add(Me.picschliessen)
        Me.pnlkopf.Controls.Add(Me.labKopfName)
        Me.pnlkopf.Location = New System.Drawing.Point(727, 0)
        Me.pnlkopf.Name = "pnlkopf"
        Me.pnlkopf.Size = New System.Drawing.Size(195, 62)
        Me.pnlkopf.TabIndex = 3
        '
        'onbtn
        '
        Me.onbtn.BackColor = System.Drawing.SystemColors.Control
        Me.onbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.onbtn.Location = New System.Drawing.Point(91, 30)
        Me.onbtn.Name = "onbtn"
        Me.onbtn.Size = New System.Drawing.Size(10, 12)
        Me.onbtn.TabIndex = 8
        Me.onbtn.TabStop = False
        '
        'txtNachrichtBody
        '
        Me.txtNachrichtBody.BackColor = System.Drawing.SystemColors.Control
        Me.txtNachrichtBody.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNachrichtBody.Location = New System.Drawing.Point(369, 100)
        Me.txtNachrichtBody.Name = "txtNachrichtBody"
        Me.txtNachrichtBody.Size = New System.Drawing.Size(553, 545)
        Me.txtNachrichtBody.TabIndex = 4
        Me.txtNachrichtBody.Text = ""
        '
        'TimerSystemTimeClock
        '
        Me.TimerSystemTimeClock.Enabled = True
        Me.TimerSystemTimeClock.Interval = 2
        '
        'frmDeskTop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(922, 708)
        Me.Controls.Add(Me.btnConnectRemotePC)
        Me.Controls.Add(Me.txtNachrichtBody)
        Me.Controls.Add(Me.pnlfuss)
        Me.Controls.Add(Me.btnStartServer)
        Me.Controls.Add(Me.tbRemoteIP)
        Me.Controls.Add(Me.pnlKontake)
        Me.Controls.Add(Me.pnlkopf)
        Me.Controls.Add(Me.tbUsername)
        Me.Controls.Add(Me.tbServerIP)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "frmDeskTop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CChatApp"
        Me.pnlKontake.ResumeLayout(False)
        Me.pnlKontake.PerformLayout()
        CType(Me.picSearch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlfuss.ResumeLayout(False)
        CType(Me.btnSend, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picschliessen, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlkopf.ResumeLayout(False)
        Me.pnlkopf.PerformLayout()
        CType(Me.onbtn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnlKontake As Panel
    Friend WithEvents pnlfuss As Panel
    Friend WithEvents pnlSearch As Panel
    Friend WithEvents txbSearch As TextBox
    Friend WithEvents tbMessageToSend As RichTextBox
    Friend WithEvents picSearch As PictureBox
    Friend WithEvents btnSend As PictureBox
    Friend WithEvents pnlunterKontakte As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
#End Region

    Sub New()
        InitializeComponent()
    End Sub

#Region "Declarations"

    Dim nStartPos As Point
    Dim nDragPos As Point

    Private Server As TCPServerControl
    Private Client As TCPClientControl

    Private Delegate Sub UpdateTextDelegate(TB As RichTextBox, txt As String)

#Region "Version"

#End Region

#End Region

#Region "communication event handler"

#End Region

#Region "properties"

#End Region

#Region "internals"

#End Region

#Region "Ereignisse"

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles picschliessen.Click
        Dim Action As Integer = MessageBox.Show("Sind Sie sicher, dass Sie das Programm Verlassen möchten?", vbNewLine, MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk)

        If Action = DialogResult.OK Then
            Me.Close()
            frmLogin.Close()
            Application.Exit()
        Else Action = DialogResult.Cancel
        End If
    End Sub
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        frmNeuKontakte.Show()
    End Sub
    Private Sub LstNachrichten_MouseDown(sender As Object, e As MouseEventArgs) Handles pnlkopf.MouseDown, pnlKontake.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            nStartPos = Me.Location
            nDragPos = Me.PointToScreen(New Point(e.X, e.Y))
        End If
    End Sub

    Private Sub LstNachrichten_MouseMove(sender As Object, e As MouseEventArgs) Handles pnlkopf.MouseMove, pnlKontake.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            ' aktuelle Mausposition bezogen auf den Desktop
            Dim nCurPos As Point = Me.PointToScreen(New Point(e.X, e.Y))

            ' Fenster an neuen Position verschieben
            Me.Location = New Point(nStartPos.X + nCurPos.X - nDragPos.X,
              nStartPos.Y + nCurPos.Y - nDragPos.Y)
        End If
    End Sub
    Private Sub TxbSearch_Click(sender As Object, e As EventArgs) Handles txbSearch.Click
        txbSearch.Text = ""
    End Sub

    Private Sub UpdateText(TB As RichTextBox, txt As String)
        If TB.InvokeRequired Then
            TB.Invoke(New UpdateTextDelegate(AddressOf UpdateText), New Object() {TB, txt})
        Else
            If txt IsNot Nothing Then TB.AppendText(txt & vbCrLf)
        End If
    End Sub

    Private Sub OnLinempfang(sender As TCPServerControl, Data As String)
        UpdateText(txtNachrichtBody, Data)
    End Sub

    Private Sub btnSendMessage_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        If tbMessageToSend.Text = "Type deine Nachricht.." Then
            MessageBox.Show("Bitte stellen Sie sicher, dass Sie eine Nachricht eingeben..", vbNewLine & vbNewLine & "Nachrichten dürfen nicht leer sein..", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Try
                Client.Send(tbUsername.Text & ": " & tbMessageToSend.Text & vbNewLine & "(Nachricht empfangen" & vbNewLine)
                txtNachrichtBody.AppendText("ME: " & tbMessageToSend.Text & vbNewLine & "Nachricht senden" & vbNewLine & vbNewLine)
                tbMessageToSend.Text = ""
            Catch ex As Exception
                MessageBox.Show("Fehler" & vbNewLine & vbNewLine & "Die Verbindung zum Remote-PC über die IP-Adresse konnte nicht hergestellt werden:" & vbNewLine & "(" & tbRemoteIP.Text & ").", vbNewLine & vbNewLine, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub txtNachrichtBody_TextChanged(sender As Object, e As EventArgs) Handles txtNachrichtBody.TextChanged

        txtNachrichtBody.ScrollToCaret()
        For i As Integer = 0 To txtNachrichtBody.Lines.Length - 1
            Dim s As String = txtNachrichtBody.Lines(i)
            Dim index As Integer = s.IndexOf("")
            Dim index1 As Integer = s.IndexOf(">")
            Dim index2 As Integer = s.IndexOf("Ich:")
            Dim index3 As Integer = s.IndexOf("Gesendete Nachricht:")
            Dim index4 As Integer = s.IndexOf("(Empfangene Nachricht:")
            Dim index5 As Integer = s.IndexOf("*")
            If index1 > -1 Then
                Dim length As Integer = s.Length - index
                index1 += txtNachrichtBody.GetFirstCharIndexFromLine(i)
                txtNachrichtBody.Select(index1, length)
                txtNachrichtBody.SelectionBackColor = Color.Green
                txtNachrichtBody.SelectionColor = Color.White
                txtNachrichtBody.SelectionAlignment = HorizontalAlignment.Center
            End If

            If index2 > -1 Then
                Dim length As Integer = s.Length - index
                index2 += txtNachrichtBody.GetFirstCharIndexFromLine(i)
                txtNachrichtBody.Select(index2, length)
                txtNachrichtBody.SelectionColor = Color.Yellow
                txtNachrichtBody.SelectionFont = New Drawing.Font("Arial Rounded MT", 10, FontStyle.Bold)
            End If

            If index3 > -1 Then
                Dim length As Integer = s.Length - index
                index3 += txtNachrichtBody.GetFirstCharIndexFromLine(i)
                txtNachrichtBody.Select(index3, length)
                txtNachrichtBody.SelectionColor = Color.Silver
                txtNachrichtBody.SelectionAlignment = HorizontalAlignment.Left
                txtNachrichtBody.SelectionFont = New Drawing.Font("Tahoma", 8, FontStyle.Regular)
            End If

            If index4 > -1 Then
                Dim length As Integer = s.Length - index
                index4 += txtNachrichtBody.GetFirstCharIndexFromLine(i)
                txtNachrichtBody.Select(index4, length)
                txtNachrichtBody.SelectionColor = Color.Silver
                txtNachrichtBody.SelectionFont = New Drawing.Font("Tahoma", 8, FontStyle.Regular)
            End If

            If index5 > -1 Then
                Dim length As Integer = s.Length - index
                index5 += txtNachrichtBody.GetFirstCharIndexFromLine(i)
                txtNachrichtBody.Select(index5, length)
                txtNachrichtBody.SelectionColor = Color.White
                txtNachrichtBody.SelectionFont = New Drawing.Font("Arial Rounded MT", 10, FontStyle.Bold)
            End If

        Next
        txtNachrichtBody.Select(0, 0)
    End Sub

    Private Sub txtReceiveIncomingMessages_LinkClicked(sender As Object, e As LinkClickedEventArgs) Handles txtNachrichtBody.LinkClicked
        System.Diagnostics.Process.Start(e.LinkText)
    End Sub

    Private Sub BtnStartServer_Click(sender As Object, e As EventArgs) Handles btnStartServer.Click
        If btnStartServer.Text = "Lokalen Dienst startenr" Then
            Try
                Server = New TCPServerControl
                AddHandler Server.MessageReceived, AddressOf OnLinempfang
                txtNachrichtBody.AppendText(vbNewLine & ">>> Lokaler Server läuft! - IP: " & tbServerIP.Text & "<<<" & vbNewLine & vbNewLine)
                btnStartServer.Text = "Lokaler Server läuft"
            Catch ex As Exception
                MessageBox.Show("Fehler", vbNewLine & "Der lokale Server kann nicht über die IP-Adresse gestartet werden:", "(" & tbServerIP.Text & ")" & vbNewLine & "Bitte überprüfen Sie, ob Ihre IP-Adresse korrekt ist.", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            MessageBox.Show("Der lokale Server läuft bereits!", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub BtnConnectRemotePC_Click(sender As Object, e As EventArgs) Handles btnConnectRemotePC.Click
        If btnConnectRemotePC.Text = "Connect to Remote Server" Then

            Try
                Client = New TCPClientControl(tbRemoteIP.Text, 65000)
                txtNachrichtBody.AppendText(">>> Erfolgreiche Verbindung mit dem Remote Server - IP:  " & tbRemoteIP.Text & " @ " & " <<<" & vbNewLine & vbNewLine)
                btnConnectRemotePC.Text = "Connected To Remote Server"
            Catch ex As Exception
                MessageBox.Show("Fehler", vbNewLine & vbNewLine & "Die Verbindung zum Remote-PC über die IP-Adresse konnte nicht hergestellt werden:" & vbNewLine & "(" & tbRemoteIP.Text & ")." & vbNewLine & vbNewLine, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            MessageBox.Show("Du bist bereits mit dem Remote Server verbunden!" & vbNewLine & vbNewLine & "Remote Server IP: " & tbRemoteIP.Text, "Network Messenger 2018 ©", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

#End Region
End Class