﻿Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Threading
Public Class TCPServerControl
    Public Event MessageReceived(sender As TCPServerControl, Data As String)

    ' SERVERKONFIGURATION
    Public ServerIP As IPAddress = IPAddress.Parse("127.0.0.1")
    Public ServerPort As Integer = 64555
    Public Server As TcpListener
    Private CommThread As Thread
    Public IsListening As Boolean = True

    ' CLIENT

    Private Client As TcpClient
    Private ClientData As StreamReader

    Public Sub New()
        Server = New TcpListener(ServerIP, ServerPort)
        Server.Start()
        CommThread = New Thread(New ThreadStart(AddressOf Listening))
        CommThread.Start()

    End Sub

    Private Sub Listening()

        ' LISTENER LOOP ERSTELLEN
        Do Until IsListening = False
            ' EINGEHENDE VERBINDUNGEN AKZEPTIEREN
            If Server.Pending = True Then
                Client = Server.AcceptTcpClient
                ClientData = New StreamReader(Client.GetStream)
            End If
            ' EREIGNIS FÜR EINGEHENDE VERBINDUNGEN AUSLÖSEN

            Try
                RaiseEvent MessageReceived(Me, ClientData.ReadLine)
            Catch ex As Exception
            End Try

            '  DEN CPU-VERBRAUCH REDUZIEREN
            Thread.Sleep(100)
        Loop

    End Sub
End Class
