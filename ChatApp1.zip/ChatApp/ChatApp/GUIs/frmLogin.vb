﻿
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Public Class frmLogin
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Friend WithEvents ChatAppDataSetBindingSource As BindingSource
    Friend WithEvents Label1 As Label
    Friend WithEvents txbPassword As TextBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents btnLogin As Button
    Friend WithEvents txbEmail As TextBox
    Friend WithEvents pnlLogin As Panel
    Friend WithEvents labBedingung As RichTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents btnSIGNUP As Button
    Friend WithEvents Panel10 As Panel
    Friend WithEvents txbReEmail As TextBox
    Friend WithEvents txbRePassword As TextBox
    Friend WithEvents txbVorname As TextBox
    Friend WithEvents ckBesaetigung As CheckBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txbNachname As TextBox
    Friend WithEvents pnlRegister As Panel
    Friend WithEvents labClose As Label
    Friend WithEvents Label7 As Label

#Region "Windows Form-Designer"

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnFrmSignup = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnFrmLogin = New System.Windows.Forms.Button()
        Me.ChatAppDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txbPassword = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.txbEmail = New System.Windows.Forms.TextBox()
        Me.pnlLogin = New System.Windows.Forms.Panel()
        Me.labClose = New System.Windows.Forms.Label()
        Me.labBedingung = New System.Windows.Forms.RichTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnSIGNUP = New System.Windows.Forms.Button()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.txbReEmail = New System.Windows.Forms.TextBox()
        Me.txbRePassword = New System.Windows.Forms.TextBox()
        Me.txbVorname = New System.Windows.Forms.TextBox()
        Me.ckBesaetigung = New System.Windows.Forms.CheckBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txbNachname = New System.Windows.Forms.TextBox()
        Me.pnlRegister = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        CType(Me.ChatAppDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlLogin.SuspendLayout()
        Me.pnlRegister.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(429, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(185, 22)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Ein Account anlegen?"
        '
        'btnFrmSignup
        '
        Me.btnFrmSignup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFrmSignup.Location = New System.Drawing.Point(437, 193)
        Me.btnFrmSignup.Name = "btnFrmSignup"
        Me.btnFrmSignup.Size = New System.Drawing.Size(77, 26)
        Me.btnFrmSignup.TabIndex = 8
        Me.btnFrmSignup.Text = "SIGN UP"
        Me.btnFrmSignup.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(433, 173)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 22)
        Me.Label3.TabIndex = 9
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.ForeColor = System.Drawing.Color.White
        Me.RichTextBox1.Location = New System.Drawing.Point(433, 122)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(250, 65)
        Me.RichTextBox1.TabIndex = 10
        Me.RichTextBox1.Text = "Mit der Erstellung eines Kontos erklären Sie sich mit unseren Allgemeinen Geschäf" &
    "tsbedingungen und dem Datenschutz einverstanden."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(49, 173)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 22)
        Me.Label5.TabIndex = 13
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(49, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(181, 22)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Hast du ein Account?"
        '
        'btnFrmLogin
        '
        Me.btnFrmLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFrmLogin.Location = New System.Drawing.Point(49, 193)
        Me.btnFrmLogin.Name = "btnFrmLogin"
        Me.btnFrmLogin.Size = New System.Drawing.Size(77, 26)
        Me.btnFrmLogin.TabIndex = 12
        Me.btnFrmLogin.Text = "LOG IN"
        Me.btnFrmLogin.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(55, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 22)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "LOG IN"
        '
        'txbPassword
        '
        Me.txbPassword.BackColor = System.Drawing.SystemColors.Control
        Me.txbPassword.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbPassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txbPassword.Location = New System.Drawing.Point(55, 190)
        Me.txbPassword.Name = "txbPassword"
        Me.txbPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txbPassword.Size = New System.Drawing.Size(173, 17)
        Me.txbPassword.TabIndex = 2
        Me.txbPassword.Text = "Password"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Black
        Me.Panel3.Location = New System.Drawing.Point(55, 172)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(173, 1)
        Me.Panel3.TabIndex = 3
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Black
        Me.Panel4.Location = New System.Drawing.Point(55, 210)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(173, 1)
        Me.Panel4.TabIndex = 4
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.Color.Chocolate
        Me.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogin.Location = New System.Drawing.Point(259, 309)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(77, 26)
        Me.btnLogin.TabIndex = 5
        Me.btnLogin.Text = "LOG IN"
        Me.btnLogin.UseVisualStyleBackColor = False
        '
        'txbEmail
        '
        Me.txbEmail.BackColor = System.Drawing.SystemColors.Control
        Me.txbEmail.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbEmail.Location = New System.Drawing.Point(55, 153)
        Me.txbEmail.Name = "txbEmail"
        Me.txbEmail.Size = New System.Drawing.Size(173, 17)
        Me.txbEmail.TabIndex = 1
        Me.txbEmail.Text = "Email"
        '
        'pnlLogin
        '
        Me.pnlLogin.BackColor = System.Drawing.SystemColors.Control
        Me.pnlLogin.Controls.Add(Me.labClose)
        Me.pnlLogin.Controls.Add(Me.txbEmail)
        Me.pnlLogin.Controls.Add(Me.btnLogin)
        Me.pnlLogin.Controls.Add(Me.Panel4)
        Me.pnlLogin.Controls.Add(Me.Panel3)
        Me.pnlLogin.Controls.Add(Me.txbPassword)
        Me.pnlLogin.Controls.Add(Me.Label1)
        Me.pnlLogin.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlLogin.Location = New System.Drawing.Point(0, 0)
        Me.pnlLogin.Name = "pnlLogin"
        Me.pnlLogin.Size = New System.Drawing.Size(377, 380)
        Me.pnlLogin.TabIndex = 15
        '
        'labClose
        '
        Me.labClose.AutoSize = True
        Me.labClose.BackColor = System.Drawing.SystemColors.Control
        Me.labClose.Dock = System.Windows.Forms.DockStyle.Left
        Me.labClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labClose.ForeColor = System.Drawing.Color.Black
        Me.labClose.Location = New System.Drawing.Point(0, 0)
        Me.labClose.Name = "labClose"
        Me.labClose.Size = New System.Drawing.Size(73, 18)
        Me.labClose.TabIndex = 6
        Me.labClose.Text = "Schließen"
        '
        'labBedingung
        '
        Me.labBedingung.BackColor = System.Drawing.SystemColors.Control
        Me.labBedingung.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.labBedingung.ForeColor = System.Drawing.Color.Black
        Me.labBedingung.Location = New System.Drawing.Point(52, 235)
        Me.labBedingung.Name = "labBedingung"
        Me.labBedingung.Size = New System.Drawing.Size(250, 46)
        Me.labBedingung.TabIndex = 13
        Me.labBedingung.Text = "Mit der Erstellung eines Kontos erklären Sie sich mit unseren Allgemeinen Geschäf" &
    "tsbedingungen und dem Datenschutz einverstanden."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(60, 58)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 22)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "SIGN UP"
        '
        'Panel8
        '
        Me.Panel8.Location = New System.Drawing.Point(32, 181)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(156, 1)
        Me.Panel8.TabIndex = 3
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Black
        Me.Panel7.Location = New System.Drawing.Point(32, 188)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(173, 1)
        Me.Panel7.TabIndex = 3
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Black
        Me.Panel6.Location = New System.Drawing.Point(32, 220)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(173, 1)
        Me.Panel6.TabIndex = 4
        '
        'btnSIGNUP
        '
        Me.btnSIGNUP.BackColor = System.Drawing.Color.Chocolate
        Me.btnSIGNUP.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSIGNUP.Location = New System.Drawing.Point(261, 309)
        Me.btnSIGNUP.Name = "btnSIGNUP"
        Me.btnSIGNUP.Size = New System.Drawing.Size(77, 26)
        Me.btnSIGNUP.TabIndex = 5
        Me.btnSIGNUP.Text = "SIGN UP"
        Me.btnSIGNUP.UseVisualStyleBackColor = False
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.Black
        Me.Panel10.Location = New System.Drawing.Point(32, 126)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(173, 1)
        Me.Panel10.TabIndex = 12
        '
        'txbReEmail
        '
        Me.txbReEmail.BackColor = System.Drawing.SystemColors.Control
        Me.txbReEmail.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbReEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbReEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbReEmail.Location = New System.Drawing.Point(32, 168)
        Me.txbReEmail.Name = "txbReEmail"
        Me.txbReEmail.Size = New System.Drawing.Size(173, 17)
        Me.txbReEmail.TabIndex = 1
        Me.txbReEmail.Text = "Email"
        '
        'txbRePassword
        '
        Me.txbRePassword.BackColor = System.Drawing.SystemColors.Control
        Me.txbRePassword.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbRePassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbRePassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbRePassword.Location = New System.Drawing.Point(32, 202)
        Me.txbRePassword.Name = "txbRePassword"
        Me.txbRePassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txbRePassword.Size = New System.Drawing.Size(173, 17)
        Me.txbRePassword.TabIndex = 2
        Me.txbRePassword.Text = "Password"
        '
        'txbVorname
        '
        Me.txbVorname.BackColor = System.Drawing.SystemColors.Control
        Me.txbVorname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbVorname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbVorname.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbVorname.Location = New System.Drawing.Point(32, 107)
        Me.txbVorname.Name = "txbVorname"
        Me.txbVorname.Size = New System.Drawing.Size(173, 17)
        Me.txbVorname.TabIndex = 9
        Me.txbVorname.Text = "Vorname"
        '
        'ckBesaetigung
        '
        Me.ckBesaetigung.AutoSize = True
        Me.ckBesaetigung.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ckBesaetigung.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ckBesaetigung.Location = New System.Drawing.Point(32, 235)
        Me.ckBesaetigung.Name = "ckBesaetigung"
        Me.ckBesaetigung.Size = New System.Drawing.Size(12, 11)
        Me.ckBesaetigung.TabIndex = 22
        Me.ckBesaetigung.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.ckBesaetigung.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ckBesaetigung.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(32, 161)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(173, 1)
        Me.Panel1.TabIndex = 24
        '
        'txbNachname
        '
        Me.txbNachname.BackColor = System.Drawing.SystemColors.Control
        Me.txbNachname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbNachname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbNachname.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txbNachname.Location = New System.Drawing.Point(32, 142)
        Me.txbNachname.Name = "txbNachname"
        Me.txbNachname.Size = New System.Drawing.Size(173, 17)
        Me.txbNachname.TabIndex = 23
        Me.txbNachname.Text = "Nachname"
        '
        'pnlRegister
        '
        Me.pnlRegister.BackColor = System.Drawing.SystemColors.Control
        Me.pnlRegister.Controls.Add(Me.Label7)
        Me.pnlRegister.Controls.Add(Me.txbNachname)
        Me.pnlRegister.Controls.Add(Me.Panel1)
        Me.pnlRegister.Controls.Add(Me.ckBesaetigung)
        Me.pnlRegister.Controls.Add(Me.txbVorname)
        Me.pnlRegister.Controls.Add(Me.txbRePassword)
        Me.pnlRegister.Controls.Add(Me.txbReEmail)
        Me.pnlRegister.Controls.Add(Me.Panel10)
        Me.pnlRegister.Controls.Add(Me.btnSIGNUP)
        Me.pnlRegister.Controls.Add(Me.Panel6)
        Me.pnlRegister.Controls.Add(Me.Panel7)
        Me.pnlRegister.Controls.Add(Me.Panel8)
        Me.pnlRegister.Controls.Add(Me.Label4)
        Me.pnlRegister.Controls.Add(Me.labBedingung)
        Me.pnlRegister.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlRegister.Location = New System.Drawing.Point(377, 0)
        Me.pnlRegister.Name = "pnlRegister"
        Me.pnlRegister.Size = New System.Drawing.Size(378, 380)
        Me.pnlRegister.TabIndex = 14
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Dock = System.Windows.Forms.DockStyle.Right
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(305, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 18)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Schließen"
        '
        'frmLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(755, 380)
        Me.Controls.Add(Me.pnlLogin)
        Me.Controls.Add(Me.pnlRegister)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnFrmLogin)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnFrmSignup)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.RichTextBox1)
        Me.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmLogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "guiLogin"
        CType(Me.ChatAppDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlLogin.ResumeLayout(False)
        Me.pnlLogin.PerformLayout()
        Me.pnlRegister.ResumeLayout(False)
        Me.pnlRegister.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents btnFrmSignup As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnFrmLogin As Button
#End Region

    Sub New()
        InitializeComponent()
        pnlRegister.Visible = False

    End Sub

#Region "Declarations"

    Dim nStartPos As Point
    Dim nDragPos As Point


    Private Sub DataLogin()
        Dim Password As String
        Dim Email As String

        Dim mycon As New ChatSer.AppDataConn.Databaseconn
        Dim command As New SqlCommand("SELECT  Email, Password FROM  login WHERE   (Email = '" & txbEmail.Text & "' ) AND (Password = '" & txbPassword.Text & "')", mycon.conn)
        mycon.conn.Open()
        Dim dataReader As SqlDataReader = command.ExecuteReader()
        If dataReader.HasRows Then
            While dataReader.Read()
                Password = dataReader("Password").ToString()
                Email = dataReader("Email").ToString()
                If txbPassword.Text = dataReader("Password") And txbEmail.Text = dataReader("Email") Then
                    'MessageBox.Show("Erfolgreich angemeldet als " & dataReader("Email"), "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    frmDeskTop.Show()
                    Me.Hide()
                    txbPassword.Text = ""
                    txbEmail.Text = ""
                End If
            End While
        Else
            MsgBox("Passwort oder Email stimmt nicht", MsgBoxStyle.Critical, "Falsche Eingaben!")
        End If
        mycon.conn.Close()

    End Sub

#End Region

#Region "communication event handler"

#End Region

#Region "properties"

#End Region

#Region "internals"
    Public Function validierenEmail(EmailAdresse) As Boolean
        Dim email As New Regex("([\w-+]+(?:\.[\w-+]+)*@)(?:[\w-+]+\.)+[a-zA-Z]{2,7}")
        If email.IsMatch(EmailAdresse) Then
            Return True
        Else
            Return False
        End If
    End Function


#End Region

#Region "Ereignisse"


    Private Sub btnFrmSignup_Click(sender As Object, e As EventArgs) Handles btnFrmSignup.Click
        pnlLogin.Visible = False
        pnlRegister.Show()
    End Sub

    Private Sub btnFrmLogin_Click(sender As Object, e As EventArgs) Handles btnFrmLogin.Click
        pnlRegister.Visible = False
        pnlLogin.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub picschliessen_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If validierenEmail(txbEmail.Text) = False Then
            MsgBox("Bitte überprüfen Sie Ihre EmailAdresse", MsgBoxStyle.Critical, "Email?")
            txbEmail.ForeColor = Color.Red
        Else
            DataLogin()
            'Dim logDB As New ChatSer.Abfragen
            'logDB.LoginData(txbEmail.Text, txbPassword.Text, frmDeskTop)
        End If
    End Sub
    Private Sub btnSIGNUP_Click(sender As Object, e As EventArgs) Handles btnSIGNUP.Click
        If ckBesaetigung.Checked = False Then
            MsgBox("Bitte Bestätigen Sie die unsere Bedingung!", MsgBoxStyle.Critical, "Bestätigung!")
            labBedingung.ForeColor = Color.Red
        Else
            If validierenEmail(txbReEmail.Text) = False Then
                MsgBox("Überprüfen Sie Ihre Email!", MsgBoxStyle.Critical, "Email Überprüfen!")
                txbReEmail.ForeColor = Color.Red
            Else
                'DataSign()
                Dim Regist As New ChatSer.Abfragen
                Regist.registData(txbVorname.Text, txbNachname.Text, Date.Now, ckBesaetigung.Checked, txbReEmail.Text, txbRePassword.Text)
            End If
        End If
    End Sub
    Private Sub RichTextBox2_Click(sender As Object, e As EventArgs) Handles labBedingung.Click
        ckBesaetigung.Checked = True
        If ckBesaetigung.Checked Then
            btnSIGNUP.BackColor = Color.Green
        Else
            btnSIGNUP.BackColor = Color.Chocolate
        End If
    End Sub

    Private Sub LiklabPwassword_Click(sender As Object, e As EventArgs)
        frmDeskTop.Show()
    End Sub
    Private Sub GuiLogin_MouseDown(sender As Object, e As MouseEventArgs) Handles pnlRegister.MouseDown, pnlLogin.MouseDown, MyBase.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            nStartPos = Me.Location
            nDragPos = Me.PointToScreen(New Point(e.X, e.Y))
        End If
    End Sub
    Private Sub PnlLogin_MouseMove(sender As Object, e As MouseEventArgs) Handles pnlRegister.MouseMove, pnlLogin.MouseMove, MyBase.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Dim nCurPos As Point = Me.PointToScreen(New Point(e.X, e.Y))
            Me.Location = New Point(nStartPos.X + nCurPos.X - nDragPos.X,
              nStartPos.Y + nCurPos.Y - nDragPos.Y)
        End If
    End Sub

    Private Sub CheckBox1_Click(sender As Object, e As EventArgs) Handles ckBesaetigung.Click
        If ckBesaetigung.Checked = True Then
            btnSIGNUP.BackColor = Color.Green
        Else
            btnSIGNUP.BackColor = Color.Chocolate
        End If
    End Sub

#End Region
End Class