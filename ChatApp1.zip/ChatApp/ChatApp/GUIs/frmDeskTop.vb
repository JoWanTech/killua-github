﻿

Imports System.Net.Sockets
Imports System.Text
Imports System.Net


<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
    Public Class frmDeskTop
        Inherits System.Windows.Forms.Form

        'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
        <System.Diagnostics.DebuggerNonUserCode()>
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub
    Friend WithEvents labKopfName As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents pnlkopf As Panel
    Friend WithEvents rtbreceivedText As RichTextBox
    Friend WithEvents tmrlistener As Windows.Forms.Timer
    Friend WithEvents labClose As Label
#Region "Windows Form-Designer"
    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnlKontake = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnlSearch = New System.Windows.Forms.Panel()
        Me.txbSearch = New System.Windows.Forms.TextBox()
        Me.picSearch = New System.Windows.Forms.PictureBox()
        Me.pnlfuss = New System.Windows.Forms.Panel()
        Me.btnSend = New System.Windows.Forms.PictureBox()
        Me.txbSendNachricht = New System.Windows.Forms.RichTextBox()
        Me.labKopfName = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlkopf = New System.Windows.Forms.Panel()
        Me.labClose = New System.Windows.Forms.Label()
        Me.rtbreceivedText = New System.Windows.Forms.RichTextBox()
        Me.tmrlistener = New System.Windows.Forms.Timer(Me.components)
        Me.pnlKontake.SuspendLayout()
        CType(Me.picSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlfuss.SuspendLayout()
        CType(Me.btnSend, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlkopf.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlKontake
        '
        Me.pnlKontake.BackColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.pnlKontake.Controls.Add(Me.Label3)
        Me.pnlKontake.Controls.Add(Me.Label2)
        Me.pnlKontake.Controls.Add(Me.pnlSearch)
        Me.pnlKontake.Controls.Add(Me.txbSearch)
        Me.pnlKontake.Controls.Add(Me.picSearch)
        Me.pnlKontake.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlKontake.Location = New System.Drawing.Point(0, 0)
        Me.pnlKontake.Name = "pnlKontake"
        Me.pnlKontake.Size = New System.Drawing.Size(362, 708)
        Me.pnlKontake.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 16.0!)
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(312, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 25)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "+"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(12, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 21)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Kontakte"
        '
        'pnlSearch
        '
        Me.pnlSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.pnlSearch.Location = New System.Drawing.Point(35, 69)
        Me.pnlSearch.Name = "pnlSearch"
        Me.pnlSearch.Size = New System.Drawing.Size(281, 1)
        Me.pnlSearch.TabIndex = 1
        '
        'txbSearch
        '
        Me.txbSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.txbSearch.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txbSearch.Location = New System.Drawing.Point(35, 54)
        Me.txbSearch.Margin = New System.Windows.Forms.Padding(4)
        Me.txbSearch.Name = "txbSearch"
        Me.txbSearch.ShortcutsEnabled = False
        Me.txbSearch.Size = New System.Drawing.Size(276, 13)
        Me.txbSearch.TabIndex = 0
        Me.txbSearch.Text = "Search..."
        '
        'picSearch
        '
        Me.picSearch.BackgroundImage = Global.ChatApp.My.Resources.Resources.searchSymb
        Me.picSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.picSearch.Location = New System.Drawing.Point(313, 53)
        Me.picSearch.Name = "picSearch"
        Me.picSearch.Size = New System.Drawing.Size(21, 17)
        Me.picSearch.TabIndex = 5
        Me.picSearch.TabStop = False
        '
        'pnlfuss
        '
        Me.pnlfuss.Controls.Add(Me.btnSend)
        Me.pnlfuss.Controls.Add(Me.txbSendNachricht)
        Me.pnlfuss.Location = New System.Drawing.Point(362, 660)
        Me.pnlfuss.Name = "pnlfuss"
        Me.pnlfuss.Size = New System.Drawing.Size(559, 48)
        Me.pnlfuss.TabIndex = 2
        '
        'btnSend
        '
        Me.btnSend.BackgroundImage = Global.ChatApp.My.Resources.Resources.send1
        Me.btnSend.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnSend.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnSend.Location = New System.Drawing.Point(529, 0)
        Me.btnSend.Name = "btnSend"
        Me.btnSend.Size = New System.Drawing.Size(30, 48)
        Me.btnSend.TabIndex = 2
        Me.btnSend.TabStop = False
        '
        'txbSendNachricht
        '
        Me.txbSendNachricht.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbSendNachricht.Dock = System.Windows.Forms.DockStyle.Left
        Me.txbSendNachricht.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbSendNachricht.Location = New System.Drawing.Point(0, 0)
        Me.txbSendNachricht.Name = "txbSendNachricht"
        Me.txbSendNachricht.Size = New System.Drawing.Size(529, 48)
        Me.txbSendNachricht.TabIndex = 0
        Me.txbSendNachricht.Text = ""
        '
        'labKopfName
        '
        Me.labKopfName.AutoSize = True
        Me.labKopfName.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labKopfName.Location = New System.Drawing.Point(87, 9)
        Me.labKopfName.Name = "labKopfName"
        Me.labKopfName.Size = New System.Drawing.Size(57, 21)
        Me.labKopfName.TabIndex = 2
        Me.labKopfName.Text = "Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(107, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "23.12.2019"
        '
        'pnlkopf
        '
        Me.pnlkopf.Controls.Add(Me.labClose)
        Me.pnlkopf.Controls.Add(Me.Label1)
        Me.pnlkopf.Controls.Add(Me.labKopfName)
        Me.pnlkopf.Location = New System.Drawing.Point(362, 0)
        Me.pnlkopf.Name = "pnlkopf"
        Me.pnlkopf.Size = New System.Drawing.Size(560, 62)
        Me.pnlkopf.TabIndex = 3
        '
        'labClose
        '
        Me.labClose.AutoSize = True
        Me.labClose.BackColor = System.Drawing.SystemColors.Control
        Me.labClose.Dock = System.Windows.Forms.DockStyle.Right
        Me.labClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labClose.Location = New System.Drawing.Point(487, 0)
        Me.labClose.Name = "labClose"
        Me.labClose.Size = New System.Drawing.Size(73, 18)
        Me.labClose.TabIndex = 5
        Me.labClose.Text = "Schließen"
        '
        'rtbreceivedText
        '
        Me.rtbreceivedText.BackColor = System.Drawing.SystemColors.Control
        Me.rtbreceivedText.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtbreceivedText.Location = New System.Drawing.Point(362, 68)
        Me.rtbreceivedText.Name = "rtbreceivedText"
        Me.rtbreceivedText.Size = New System.Drawing.Size(559, 567)
        Me.rtbreceivedText.TabIndex = 4
        Me.rtbreceivedText.Text = ""
        '
        'tmrlistener
        '
        Me.tmrlistener.Enabled = True
        Me.tmrlistener.Interval = 2
        '
        'frmDeskTop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(922, 708)
        Me.Controls.Add(Me.rtbreceivedText)
        Me.Controls.Add(Me.pnlfuss)
        Me.Controls.Add(Me.pnlKontake)
        Me.Controls.Add(Me.pnlkopf)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Name = "frmDeskTop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlKontake.ResumeLayout(False)
        Me.pnlKontake.PerformLayout()
        CType(Me.picSearch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlfuss.ResumeLayout(False)
        CType(Me.btnSend, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlkopf.ResumeLayout(False)
        Me.pnlkopf.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlKontake As Panel
    Friend WithEvents pnlfuss As Panel
    Friend WithEvents pnlSearch As Panel
    Friend WithEvents txbSearch As TextBox
    Friend WithEvents txbSendNachricht As RichTextBox
    Friend WithEvents picSearch As PictureBox
    Friend WithEvents btnSend As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
#End Region



#Region "Declarations"

    Dim nStartPos As Point
    Dim nDragPos As Point

    Dim clientSocket As New TcpClient()
    Dim serverStream As NetworkStream
    Dim readData As String
    Dim infiniteCounter As Integer

    Private Sub getMessage()
        For infiniteCounter = 1 To 2
            infiniteCounter = 1
            serverStream = clientSocket.GetStream()
            Dim buffSize As Integer
            Dim inStream(1024) As Byte
            buffSize = clientSocket.ReceiveBufferSize
            serverStream.Read(inStream, 0, buffSize)
            Dim returndata As String = System.Text.Encoding.ASCII.GetString(inStream)
            readData = "" + returndata
            msg()
        Next
    End Sub
    Private Sub msg()
        If Me.InvokeRequired Then
            Me.Invoke(New MethodInvoker(AddressOf msg))
        Else
            rtbreceivedText.Text = rtbreceivedText.Text + Environment.NewLine + " >> " + readData
        End If
    End Sub

    Public Sub New()
        ' Dieser Aufruf ist für den Designer erforderlich.
        InitializeComponent()
    End Sub

#End Region

#Region "Ereignisse"


    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        frmNeuKontakte.Show()
    End Sub

    Private Sub LstNachrichten_MouseDown(sender As Object, e As MouseEventArgs) Handles pnlkopf.MouseDown, pnlKontake.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            nStartPos = Me.Location
            nDragPos = Me.PointToScreen(New Point(e.X, e.Y))
        End If
    End Sub

    Private Sub LstNachrichten_MouseMove(sender As Object, e As MouseEventArgs) Handles pnlkopf.MouseMove, pnlKontake.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            ' aktuelle Mausposition bezogen auf den Desktop
            Dim nCurPos As Point = Me.PointToScreen(New Point(e.X, e.Y))

            ' Fenster an neuen Position verschieben
            Me.Location = New Point(nStartPos.X + nCurPos.X - nDragPos.X,
              nStartPos.Y + nCurPos.Y - nDragPos.Y)
        End If
    End Sub
    Private Sub TxbSearch_Click(sender As Object, e As EventArgs) Handles txbSearch.Click
        txbSearch.Text = ""
    End Sub


    Private Sub PicSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        Dim outStream As Byte()

        outStream = System.Text.Encoding.ASCII.GetBytes(txbSendNachricht.Text + "$")
        serverStream.Write(outStream, 0, outStream.Length)
        serverStream.Flush()
    End Sub

    Private Sub PicSearch_Click(sender As Object, e As EventArgs) Handles picSearch.Click
        'Dim IpEnd As IPEndPoint = New IPEndPoint(IPAddress.Any, 8080)
        Try
            clientSocket.Connect("127.0.0.1", 8080)
            serverStream = clientSocket.GetStream()
            If clientSocket.Connected Then
                readData = "Conected to Chat Server ..."
                msg()
            End If
            Dim outStream As Byte() =
            System.Text.Encoding.ASCII.GetBytes(txbSearch.Text + "$")
            serverStream.Write(outStream, 0, outStream.Length)
            serverStream.Flush()

            Dim ctThread As Threading.Thread = New Threading.Thread(AddressOf getMessage)
            ctThread.Start()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub LabClose_Click(sender As Object, e As EventArgs) Handles labClose.Click
        Me.Close()
        frmLogin.Close()
    End Sub

    Private Sub LabClose_MouseLeave(sender As Object, e As EventArgs)
        labClose.BackColor = Color.Green
    End Sub

    Private Sub LabClose_MouseEnter(sender As Object, e As EventArgs)
        labClose.BackColor = Color.Red
    End Sub
#End Region
End Class