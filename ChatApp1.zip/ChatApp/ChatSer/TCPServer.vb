﻿Option Strict On
Imports System.Net.Sockets
Imports System.Text
Imports System.Net

Module Module1

    Private _clientsList As New Hashtable
    Private _Server As TcpListener '(444)
    Private IpEnd As IPEndPoint


    Private _client As TcpClient
    Private _zeahler As Integer


    Private _bytesFrom(1024) As Byte
    Private _ClientData As String

    Private networkStream As NetworkStream
    Private _Handlclient As New handleClinet

    Private Item As DictionaryEntry

    Private broadcastSocket As TcpClient
    Private broadcastStream As NetworkStream
    Private broadcastBytes As [Byte]()




    Sub Main()
        IpEnd = New IPEndPoint(IPAddress.Any, 8080)
        _Server = New TcpListener(IpEnd)
        _Server.Start()
        msg("Chat Server Started ....")
        _zeahler = 0

        While (True)
            _zeahler += 1
            _client = _Server.AcceptTcpClient()

            networkStream = _client.GetStream()
            networkStream.Read(_bytesFrom, 0, CInt(_client.ReceiveBufferSize))

            _ClientData = System.Text.Encoding.ASCII.GetString(_bytesFrom)
            _ClientData = _ClientData.Substring(0, _ClientData.IndexOf("$"))

            _clientsList(_ClientData) = _client
            broadcast(_ClientData + " Joined ", _ClientData, False)

            msg(_ClientData + " Joined chat room ")

            _Handlclient.startClient(_client, _ClientData, _clientsList)
        End While
        _client.Close()
        _Server.Stop()
        msg("exit")
        Console.ReadLine()
    End Sub



    Public Sub broadcast(ByVal msg As String, ByVal uName As String, ByVal flag As Boolean)

        For Each Item In _clientsList
            broadcastSocket = CType(Item.Value, TcpClient)
            broadcastStream = broadcastSocket.GetStream()
            If flag = True Then
                broadcastBytes = Encoding.ASCII.GetBytes(uName + " says : " + msg)
            Else
                broadcastBytes = Encoding.ASCII.GetBytes(msg)
            End If
            broadcastStream.Write(broadcastBytes, 0, broadcastBytes.Length)
            broadcastStream.Flush()
        Next
    End Sub
    Public Sub msg(ByVal mesg As String)
        mesg.Trim()
        Console.WriteLine(" >> " + mesg)
    End Sub




End Module