﻿
Imports System.Data.SqlClient

Namespace AppDataConn
    Public Class Databaseconn


        Private connection As New SqlConnection("Data Source=127.0.0.1;Initial Catalog=ChatApp;Integrated Security=True")



        Public Function open() As SqlConnection
            Try
                connection.Open()
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical)
            End Try
            Return connection
        End Function

        Public Function close() As SqlConnection
            Try
                connection.Close()
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical)
            End Try
            Return connection
        End Function


    End Class
End Namespace



