﻿Imports System.Text.RegularExpressions
Imports System.Data.SqlClient

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Public Class frmNeuKontakte
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txbKoNachname As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel

#Region "Windows Form-Designer"
    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.pnlRegister = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txbKoNachname = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.txbKoVorname = New System.Windows.Forms.TextBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.txbKoEmail = New System.Windows.Forms.TextBox()
        Me.Btnloeschen = New System.Windows.Forms.Button()
        Me.picSignClose = New System.Windows.Forms.PictureBox()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.btnhinzufuegen = New System.Windows.Forms.Button()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.pnlRegister.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSignClose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlRegister
        '
        Me.pnlRegister.BackColor = System.Drawing.SystemColors.Control
        Me.pnlRegister.Controls.Add(Me.PictureBox1)
        Me.pnlRegister.Controls.Add(Me.txbKoNachname)
        Me.pnlRegister.Controls.Add(Me.Panel1)
        Me.pnlRegister.Controls.Add(Me.Panel2)
        Me.pnlRegister.Controls.Add(Me.PictureBox5)
        Me.pnlRegister.Controls.Add(Me.txbKoVorname)
        Me.pnlRegister.Controls.Add(Me.PictureBox3)
        Me.pnlRegister.Controls.Add(Me.txbKoEmail)
        Me.pnlRegister.Controls.Add(Me.Btnloeschen)
        Me.pnlRegister.Controls.Add(Me.picSignClose)
        Me.pnlRegister.Controls.Add(Me.Panel11)
        Me.pnlRegister.Controls.Add(Me.Panel12)
        Me.pnlRegister.Controls.Add(Me.btnhinzufuegen)
        Me.pnlRegister.Controls.Add(Me.Panel7)
        Me.pnlRegister.Controls.Add(Me.Panel8)
        Me.pnlRegister.Controls.Add(Me.Label4)
        Me.pnlRegister.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlRegister.Location = New System.Drawing.Point(0, 0)
        Me.pnlRegister.Name = "pnlRegister"
        Me.pnlRegister.Size = New System.Drawing.Size(383, 357)
        Me.pnlRegister.TabIndex = 15
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.ChatApp.My.Resources.Resources.profil
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox1.Location = New System.Drawing.Point(14, 147)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox1.TabIndex = 28
        Me.PictureBox1.TabStop = False
        '
        'txbKoNachname
        '
        Me.txbKoNachname.BackColor = System.Drawing.SystemColors.Control
        Me.txbKoNachname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbKoNachname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbKoNachname.ForeColor = System.Drawing.Color.Black
        Me.txbKoNachname.Location = New System.Drawing.Point(45, 158)
        Me.txbKoNachname.Name = "txbKoNachname"
        Me.txbKoNachname.Size = New System.Drawing.Size(173, 17)
        Me.txbKoNachname.TabIndex = 25
        Me.txbKoNachname.Text = "Nachname"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(45, 178)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(173, 1)
        Me.Panel1.TabIndex = 26
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(45, 171)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(156, 1)
        Me.Panel2.TabIndex = 27
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = Global.ChatApp.My.Resources.Resources.profil
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox5.Location = New System.Drawing.Point(14, 110)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox5.TabIndex = 24
        Me.PictureBox5.TabStop = False
        '
        'txbKoVorname
        '
        Me.txbKoVorname.BackColor = System.Drawing.SystemColors.Control
        Me.txbKoVorname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbKoVorname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbKoVorname.ForeColor = System.Drawing.Color.Black
        Me.txbKoVorname.Location = New System.Drawing.Point(45, 121)
        Me.txbKoVorname.Name = "txbKoVorname"
        Me.txbKoVorname.Size = New System.Drawing.Size(173, 17)
        Me.txbKoVorname.TabIndex = 1
        Me.txbKoVorname.Text = "Vorname"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = Global.ChatApp.My.Resources.Resources.mail
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox3.Location = New System.Drawing.Point(14, 183)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(27, 32)
        Me.PictureBox3.TabIndex = 22
        Me.PictureBox3.TabStop = False
        '
        'txbKoEmail
        '
        Me.txbKoEmail.BackColor = System.Drawing.SystemColors.Control
        Me.txbKoEmail.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txbKoEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.txbKoEmail.ForeColor = System.Drawing.Color.Black
        Me.txbKoEmail.Location = New System.Drawing.Point(45, 194)
        Me.txbKoEmail.Name = "txbKoEmail"
        Me.txbKoEmail.Size = New System.Drawing.Size(173, 17)
        Me.txbKoEmail.TabIndex = 3
        Me.txbKoEmail.Text = "Email"
        '
        'Btnloeschen
        '
        Me.Btnloeschen.BackColor = System.Drawing.Color.Chocolate
        Me.Btnloeschen.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnloeschen.Location = New System.Drawing.Point(155, 252)
        Me.Btnloeschen.Name = "Btnloeschen"
        Me.Btnloeschen.Size = New System.Drawing.Size(77, 26)
        Me.Btnloeschen.TabIndex = 6
        Me.Btnloeschen.Text = "Löschen"
        Me.Btnloeschen.UseVisualStyleBackColor = False
        '
        'picSignClose
        '
        Me.picSignClose.BackgroundImage = Global.ChatApp.My.Resources.Resources.close
        Me.picSignClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.picSignClose.Location = New System.Drawing.Point(360, 3)
        Me.picSignClose.Name = "picSignClose"
        Me.picSignClose.Size = New System.Drawing.Size(17, 18)
        Me.picSignClose.TabIndex = 15
        Me.picSignClose.TabStop = False
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.Black
        Me.Panel11.Location = New System.Drawing.Point(45, 141)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(173, 1)
        Me.Panel11.TabIndex = 10
        '
        'Panel12
        '
        Me.Panel12.Location = New System.Drawing.Point(45, 134)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(156, 1)
        Me.Panel12.TabIndex = 11
        '
        'btnhinzufuegen
        '
        Me.btnhinzufuegen.BackColor = System.Drawing.Color.Chocolate
        Me.btnhinzufuegen.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnhinzufuegen.Location = New System.Drawing.Point(238, 252)
        Me.btnhinzufuegen.Name = "btnhinzufuegen"
        Me.btnhinzufuegen.Size = New System.Drawing.Size(77, 26)
        Me.btnhinzufuegen.TabIndex = 5
        Me.btnhinzufuegen.Text = "Hinzufügen"
        Me.btnhinzufuegen.UseVisualStyleBackColor = False
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Black
        Me.Panel7.Location = New System.Drawing.Point(45, 214)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(173, 1)
        Me.Panel7.TabIndex = 3
        '
        'Panel8
        '
        Me.Panel8.Location = New System.Drawing.Point(45, 207)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(156, 1)
        Me.Panel8.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(34, 58)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(164, 22)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "NEUE KONTAKTE"
        '
        'guiNeuKontakte
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(383, 357)
        Me.Controls.Add(Me.pnlRegister)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "guiNeuKontakte"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "guiNeuKontakte"
        Me.pnlRegister.ResumeLayout(False)
        Me.pnlRegister.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSignClose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlRegister As Panel
    Friend WithEvents picSignClose As PictureBox
    Friend WithEvents txbKoVorname As TextBox
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents btnhinzufuegen As Button
    Friend WithEvents txbKoEmail As TextBox
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Btnloeschen As Button
#End Region



#Region "Declarations"

    Dim nStartPos As Point
    Dim nDragPos As Point


    Public Function validierenEmail(EmailAdresse) As Boolean
        validierenEmail = New Regex("([\w-+]+(?:\.[\w-+]+)*@)(?:[\w-+]+\.)+[a-zA-Z]{2,7}").IsMatch(EmailAdresse)
    End Function

    'Private Function getVorname(Input As String) As String 'erwarte InPut als "     Vorame    , Nachname  "
    '    Dim Teile As String() = Input.Split(",")
    '    getVorname = Teile(0).Trim()
    'End Function
    'Private Function getNachname(Input As String) As String 'erwarte InPut als "Vorame, Nachname"
    '    Dim Teile As String() = Input.Split(",")
    '    getNachname = Teile(1).Trim()
    'End Function

    Private Sub DataNeueKont()
        Dim mycon As New ChatSer.AppDataConn.Databaseconn
        Dim command As New SqlCommand("insert into Kontakte (Vorname, Nachname, email, erstellt_am)
                                       values (@vorname, @nachname, @email, @erstellt_am)", mycon.conn)
        command.Parameters.Add("@email", SqlDbType.VarChar).Value = txbKoEmail.Text
        command.Parameters.Add("@erstellt_am", SqlDbType.DateTime).Value = DateTime.Now
        command.Parameters.Add("@vorname", SqlDbType.VarChar).Value = txbKoVorname.Text
        command.Parameters.Add("@Nachname", SqlDbType.VarChar).Value = txbKoNachname.Text
        mycon.conn.Open()
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable()
        adapter.Fill(table)
        If table.Rows.Count() <= 0 Then
            MsgBox("Die neue Kontakt ist erfolgreich eingefügt", MsgBoxStyle.Information, "Neue Kontakte")
        Else
            MsgBox("Die neue Kontakt konnte nicht erstellt werden!", MsgBoxStyle.Critical, "Fehler")
        End If
        mycon.conn.Close()
    End Sub

    Private Sub DataKontDelete()

        Dim mycon As New ChatSer.AppDataConn.Databaseconn
        Dim command As New SqlCommand("delete from  Kontakte  where vorname =@vorname and nachname =@nachname", mycon.conn)
        command.Parameters.Add("@vorname", SqlDbType.VarChar).Value = txbKoVorname.Text
        command.Parameters.Add("@nachname", SqlDbType.VarChar).Value = txbKoVorname.Text

        mycon.conn.Open()
        If command.ExecuteNonQuery() Then
            MsgBox("Die kontakt ist erfolgreich gelöscht", MsgBoxStyle.Information, "gelöscht")
        Else
            MsgBox("Die kontakt konnte leider nicht gelöscht werden", MsgBoxStyle.Exclamation, "Fehler!")
        End If

    End Sub

#End Region


#Region "Ereignisse"

    Private Sub picSignClose_Click_1(sender As Object, e As EventArgs) Handles picSignClose.Click
        Me.Close()
    End Sub

    Private Sub btnSpeichern_Click(sender As Object, e As EventArgs) Handles btnhinzufuegen.Click

        If validierenEmail(txbKoEmail.Text) = False Then
            MsgBox("Bitte überprüfen Sie die Email Adresse", MsgBoxStyle.Critical, "Email?")
            txbKoEmail.ForeColor = Color.Red
        Else
            If (txbKoVorname.Text = "" AndAlso txbKoNachname.Text <> "") OrElse (txbKoVorname.Text <> "" AndAlso txbKoNachname.Text = "") Then
                MsgBox("Bitte mindenstens eins von den Beiden (Vorname oder Nachname) muss erfüllt werden", MsgBoxStyle.Critical, "Bitte mit Daten erfüllen!")
            Else
                DataNeueKont()
            End If
        End If
    End Sub

    Private Sub loeschen_Click(sender As Object, e As EventArgs) Handles Btnloeschen.Click
        DataKontDelete()
    End Sub

    Private Sub PnlRegister_MouseMove(sender As Object, e As MouseEventArgs) Handles pnlRegister.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            ' aktuelle Mausposition bezogen auf den Desktop
            Dim nCurPos As Point = Me.PointToScreen(New Point(e.X, e.Y))

            ' Fenster an neuen Position verschieben
            Me.Location = New Point(nStartPos.X + nCurPos.X - nDragPos.X,
              nStartPos.Y + nCurPos.Y - nDragPos.Y)
        End If
    End Sub

    Private Sub PnlRegister_MouseDown(sender As Object, e As MouseEventArgs) Handles pnlRegister.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            nStartPos = Me.Location
            nDragPos = Me.PointToScreen(New Point(e.X, e.Y))
        End If
    End Sub

    Private Sub TxbKoVorname_Click(sender As Object, e As EventArgs) Handles txbKoVorname.Click
        txbKoVorname.Text = ""
    End Sub

    Private Sub TxbKoNachname_Click(sender As Object, e As EventArgs) Handles txbKoNachname.Click
        txbKoNachname.Text = ""
    End Sub

    Private Sub TxbKoEmail_Click(sender As Object, e As EventArgs) Handles txbKoEmail.Click
        txbKoEmail.Text = ""
    End Sub

#End Region
End Class