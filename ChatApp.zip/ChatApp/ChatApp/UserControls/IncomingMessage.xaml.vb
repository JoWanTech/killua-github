﻿Public Class IncomingMessage

End Class
