﻿Imports System.Net.Sockets
Imports System.Text

Public Class handleClinet

    Private clientSocket As TcpClient
    Private clNo As String
    Private clientsList As Hashtable
    'Dim infiniteCounter As Integer
    Private requestCount As Integer
    Private bytesFrom(10024) As Byte
    Private dataFromClient As String
    'Dim sendBytes As [Byte]()
    'Dim serverResponse As String
    Private rCount As String
    Private ctThread As Threading.Thread
    Private networkStream As NetworkStream



    Public Sub startClient(ByVal inClientSocket As TcpClient, ByVal clineNo As String, ByVal cList As Hashtable)
        Me.clientSocket = inClientSocket
        Me.clNo = clineNo
        Me.clientsList = cList
        ctThread = New Threading.Thread(AddressOf doChat)
        ctThread.Start()
    End Sub

    Private Sub doChat()
        requestCount = 0
        While (True)
            Try
                requestCount = requestCount + 1
                networkStream = clientSocket.GetStream()
                networkStream.Read(bytesFrom, 0, CInt(clientSocket.ReceiveBufferSize))
                dataFromClient = System.Text.Encoding.ASCII.GetString(bytesFrom)
                dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"))

                msg("From client - " + clNo + " : " + dataFromClient)
                rCount = Convert.ToString(requestCount)
                broadcast(dataFromClient, clNo, True)
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End While
    End Sub

End Class
