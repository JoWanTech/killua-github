﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class Abfragen

    Dim myconn As ChatSer.AppDataConn.Databaseconn
    Private Sub UserLogin()
        Dim command As New SqlCommand("insert into benutzer (Anrede_Id, vorname, Nachname, email, erstellt_am, upgedatet_am, Password, Bestaetigung)
                                                     values (@Anrede_Id, @vorname, @Nachname,@email, @erstellt_am, @upgedatet_am, @password, @Bestaetigung)", myconn.conn)

    End Sub
End Class
