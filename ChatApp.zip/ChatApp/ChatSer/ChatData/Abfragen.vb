﻿Imports System.Data.Sql
Imports System.Data.SqlClient


Public Class Abfragen
    Public Sub FilterData(ByVal value As String)

        Dim myconn As New ChatSer.AppDataConn.Databaseconn
        Dim Abfrage As String = "select * from kontakte where concat(vorname, nachname) like '%" & value & "%'"

        Dim command As New SqlCommand(Abfrage, myconn.conn)
        Dim adabter As New SqlDataAdapter(command)
        Dim table As New DataTable()
        adabter.Fill(table)


    End Sub


    Public Sub DataNeueKont(ByVal email As String,
                            ByVal vorname As String,
                             ByVal nachname As String,
                             ByVal erstellt As String,
                             ByVal upgedatet As String
                             )
        Dim mycon As New ChatSer.AppDataConn.Databaseconn
        Dim command As New SqlCommand("insert into contacts (Vorname, Nachname, email, erstellt_am, upgedatet_am)
                                       values (@vorname, @nachname, @email, @erstellt_am, @upgedatet_am)", mycon.conn)
        command.Parameters.Add("@email", SqlDbType.VarChar).Value = email
        command.Parameters.Add("@vorname", SqlDbType.VarChar).Value = vorname
        command.Parameters.Add("@Nachname", SqlDbType.VarChar).Value = nachname
        command.Parameters.Add("@erstellt_am", SqlDbType.DateTime).Value = erstellt
        command.Parameters.Add("@upgedatet_am", SqlDbType.DateTime).Value = upgedatet
        mycon.conn.Open()

        If command.ExecuteNonQuery() = 1 Then
            MsgBox("Die neue Kontakt ist erfolgreich eingefügt", MsgBoxStyle.Information, "Neue Kontakte")
        Else
            MsgBox("Die neue Kontakt konnte nicht erstellt werden!", MsgBoxStyle.Critical, "Fehler")
        End If
        mycon.conn.Close()
    End Sub

    Public Sub Datadelete(ByVal vorname As String, ByVal nachname As String)
        Dim mycon As New ChatSer.AppDataConn.Databaseconn
        Dim command As New SqlCommand("delete from  contacts  where vorname =@vorname and nachname =@nachname", mycon.conn)
        command.Parameters.Add("@vorname", SqlDbType.VarChar).Value = vorname
        command.Parameters.Add("@nachname", SqlDbType.VarChar).Value = nachname

        mycon.conn.Open()

        If command.ExecuteNonQuery() = 1 Then
            MsgBox("Die kontakt ist erfolgreich gelöscht", MsgBoxStyle.Information, "gelöscht")
        Else
            MsgBox("Die kontakt konnte leider nicht gelöscht werden", MsgBoxStyle.Exclamation, "Fehler!")
        End If

    End Sub


    'Public Sub LoginData(ByVal email As String,
    '                     ByVal password As String, ByVal frmObject As Object)


    '    Dim mycon As New ChatSer.AppDataConn.Databaseconn
    '    Dim command As New SqlCommand("SELECT  Email, Password FROM  login WHERE   (Email = '" & email & "' ) AND (Password = '" & password & "')", mycon.conn)
    '    mycon.conn.Open()
    '    Using dataReader As SqlDataReader = command.ExecuteReader()
    '        If dataReader.HasRows Then
    '            While dataReader.Read()
    '                password = dataReader("Password").ToString()
    '                email = dataReader("Email").ToString()
    '                If email = dataReader("Password") And password = dataReader("Email") Then
    '                    frmObject.Show()
    '                    '                Me.Hide()
    '                    '                txbPassword.Text = ""
    '                    '                txbEmail.Text = ""
    '                    email = ""
    '                    password = ""
    '                End If
    '            End While
    '        Else
    '            MsgBox("Passwort oder Email stimmt nicht!", MsgBoxStyle.Critical, "Falsche Eingaben!")
    '        End If
    '    End Using
    '    mycon.conn.Close()
    'End Sub

    Private Function _userId() As String
        Dim myconn As New ChatSer.AppDataConn.Databaseconn
        Dim _usId As String
        _usId = "select max(user_id +1) from userinfos"
        Dim cmd As New SqlCommand(_usId, myconn.conn)
        myconn.conn.Open()
        Dim dataReader As SqlDataReader = cmd.ExecuteReader()

        Return _usId
    End Function

    Public Sub registData(ByVal vorname As String,
                           ByVal Nachname As String,
                           ByVal geburstag As Date,
                           ByVal bstaetigung As Boolean,
                           ByVal email As String,
                           ByVal password As String)

        Dim myconn As New ChatSer.AppDataConn.Databaseconn


        Dim sqlString As String
        sqlString = "insert into userinfos (vorname, Nachname, geburstag, erstellt_am, upgedatet_am, bstaetigung)
                                                     values (@vorname, @Nachname,@geburstag, @erstellt_am, @upgedatet_am,  @bstaetigung)"

        myconn.conn.Open()

        sqlString &= "insert into login (" & _userId() & ", email, password) values (@user_id, @email, @password)"

        Dim command As New SqlCommand(sqlString, myconn.conn)

        command.Parameters.Add("@vorname", SqlDbType.VarChar).Value = vorname
        command.Parameters.Add("@Nachname", SqlDbType.VarChar).Value = Nachname
        command.Parameters.Add("@geburstag", SqlDbType.VarChar).Value = geburstag
        command.Parameters.Add("@user_id", SqlDbType.VarChar).Value = _userId()
        command.Parameters.Add("@email", SqlDbType.VarChar).Value = email
        command.Parameters.Add("@password", SqlDbType.VarChar).Value = password
        command.Parameters.Add("@bstaetigung", SqlDbType.VarChar).Value = bstaetigung
        command.Parameters.Add("@upgedatet_am", SqlDbType.DateTime).Value = DateTime.Now
        command.Parameters.Add("@erstellt_am", SqlDbType.DateTime).Value = DateTime.Now
        Dim adapter As New SqlDataAdapter(command)

        Dim table As New DataTable()
        adapter.Fill(table)
        If table.Rows.Count() <= 0 Then
            MsgBox("Sie Wurden erfolgreich registriert", MsgBoxStyle.Information)
        Else
            MsgBox("Die Verbindung zur Datenbank ist schiefgelaufen!", MsgBoxStyle.Critical, "Fehler")
        End If
        myconn.conn.Close()
    End Sub




End Class
